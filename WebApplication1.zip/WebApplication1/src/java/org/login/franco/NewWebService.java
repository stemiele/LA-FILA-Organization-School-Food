/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.login.franco;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Franco_Mattia
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {
    public static String PASSWORD = "boaresco";


    /**
     * Web service operation
     */
    @WebMethod(operationName = "Login")
    public boolean Login(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        String user = "mattia";
        String psw = PASSWORD;
        boolean corretto = false;
        if(user.equals(username) && psw.equals(password))
            corretto = true;
        return corretto;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Registrati")
    public boolean Registrati(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        if(username.equals("mattia") && password.equals(PASSWORD))
            return true;
        else
            return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "modifica")
    public boolean modifica(@WebParam(name = "username") String username, @WebParam(name = "vecchiaPassword") String vecchiaPassword, @WebParam(name = "nuovaPassword") String nuovaPassword, @WebParam(name = "confermaNuovaPassword") String confermaNuovaPassword){
        String passwordV = PASSWORD;
        boolean corretto = false;
        if(passwordV.equals(vecchiaPassword)){
            if(nuovaPassword.equals(confermaNuovaPassword)){
                PASSWORD = nuovaPassword;
                corretto = true;
            }
        }
        else
            return corretto;
    }
}
