/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package franco;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author franco_mattia
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {

public static String PASSWORD = "boaresco";
    /**
     * Web service operation
     */
    @WebMethod(operationName = "login")
    public boolean login(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        String user = "mattia";
        String psw = PASSWORD;
        boolean corretto = false;
        if(user.equals(username) && psw.equals(password))
            corretto = true;
        return corretto;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Registrati")
    public boolean Registrati(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        if(username.equals("mattia") && password.equals(PASSWORD))
            return true;
        else
            return false;
    }


}
