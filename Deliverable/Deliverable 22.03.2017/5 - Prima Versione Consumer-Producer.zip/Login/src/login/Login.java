/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author franco_mattia
 */
public class Login {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String username;
        String password;
        username = "admin";
        password = "admin";
        boolean s = login(username,password);
        System.out.println(s);
    }

    private static boolean login(java.lang.String username, java.lang.String password) {
        franco.NewWebService_Service service = new franco.NewWebService_Service();
        franco.NewWebService port = service.getNewWebServicePort();
        return port.login(username, password);
    }
}
