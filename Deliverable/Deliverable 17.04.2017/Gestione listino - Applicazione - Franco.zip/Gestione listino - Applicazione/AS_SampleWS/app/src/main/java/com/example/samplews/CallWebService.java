package com.example.samplews;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;


public class CallWebService extends AsyncTask<String, String, String> {

    // vettore dove memorizzare la lista dei valori restituiti dal web service
    private ArrayList<String> arraylist;

    // TextView dove visualizzare il risultato
    private TextView textViewRisultato;

    // URL corrispondente al web service
    public final static String URL = "http://10.0.2.2:8080/NB_WSApplicationTestDB/WSApplicationTestDB";
    // target name space
    public final static String NAMESPACE = "http://application.giodabg.org/";

    // nome dell'operazione
    public final static String METHOD_NAME_LIST = "getList";
    // nome dei parametri
    private static final String PARAMETER_NAME_LIST1 = "nome";
    // valore per il parametro
    private static final String PARAMETER_VALUE_LIST1 = "operazioni";

    // nome dell'operazione
    public final static String METHOD_NAME_ADD = "add";
    public final static String METHOD_NAME_MODIFY = "modify";
    public final static String METHOD_NAME_DELETE = "delete";
    // nome dei parametri
    private static final String PARAMETER_NAME_ADD1 = "nome";
    private static final String PARAMETER_NAME_ADD2 = "descrizione";
    private static final String PARAMETER_NAME_ADD3 = "prezzo";

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        // Things to be done before execution of long running operation. For
        // example showing ProgessDialog

        // creazione vettore per memorizzare il o i valori ricevuti dal web service
        arraylist = new ArrayList<String>();
    }


    @Override
    protected String doInBackground(String... params) {
        String str;

        if (params[0].equals(METHOD_NAME_ADD)) {

            // impostazione nome esteso dell'operazione
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_ADD;

            // creazione dell'oggetto per la comunicazione con il web service
            // impostando il namespace e l'operazione da eseguire
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_ADD);

            // preparazione delle proprietà/parametri dell'operazione
            PropertyInfo propertyInfo = new PropertyInfo();

            // FORMA ESTESA: aggiunta di un parametro con nome PARAMETER_NAME_ADD1 di tipo int
            propertyInfo.setName(PARAMETER_NAME_ADD1);
            propertyInfo.setValue(params[1]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);

            // FORMA SEMPLIFICATA: aggiunta di un parametro con nome PARAMETER_NAME_ADD2 di tipo base
            soapObject.addProperty(PARAMETER_NAME_ADD2, params[2]);
            soapObject.addProperty(PARAMETER_NAME_ADD3, params[3]);

            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            // creazione della busta SOAP da inviare
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            // inserimento nella busta dell'oggetto SOAP
            envelope.setOutputSoapObject(soapObject);

            // creazione della connessione con protocollo HTTP al web service
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);

            try {
                // richiesta di esecuzione dell'operazione SOAP_ACTION ssui dati contenuti nella busta SOAP
                httpTransportSE.call(SOAP_ACTION, envelope);

                // ricezione della risposta
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();

                // FORMA SEMPLIFICATA: estrazione dalla risposta del contenuto
                str = soapPrimitive.toString();

                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (params[0].equals(METHOD_NAME_DELETE)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_DELETE;

            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_DELETE);

            // FORMA SEMPLIFICATA: aggiunta di un parametro con nome PARAMETER_NAME_ADD2 di tipo base
            soapObject.addProperty("nomeProd", params[1]);

            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            // creazione della busta SOAP da inviare
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            // inserimento nella busta dell'oggetto SOAP
            envelope.setOutputSoapObject(soapObject);

            // creazione della connessione con protocollo HTTP al web service
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);

            try {
                // richiesta di esecuzione dell'operazione SOAP_ACTION ssui dati contenuti nella busta SOAP
                httpTransportSE.call(SOAP_ACTION, envelope);

                // ricezione della risposta
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();

                // FORMA SEMPLIFICATA: estrazione dalla risposta del contenuto
                str = soapPrimitive.toString();

                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if (params[0].equals(METHOD_NAME_MODIFY)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_MODIFY;

            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_MODIFY);

            // FORMA SEMPLIFICATA: aggiunta di un parametro con nome PARAMETER_NAME_ADD2 di tipo base
            soapObject.addProperty("nomeProd", params[1]);
            soapObject.addProperty("nuovoNome", params[2]);
            soapObject.addProperty("prezzo", params[3]);

            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            // creazione della busta SOAP da inviare
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            // inserimento nella busta dell'oggetto SOAP
            envelope.setOutputSoapObject(soapObject);

            // creazione della connessione con protocollo HTTP al web service
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);

            try {
                // richiesta di esecuzione dell'operazione SOAP_ACTION ssui dati contenuti nella busta SOAP
                httpTransportSE.call(SOAP_ACTION, envelope);

                // ricezione della risposta
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();

                // FORMA SEMPLIFICATA: estrazione dalla risposta del contenuto
                str = soapPrimitive.toString();

                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

}