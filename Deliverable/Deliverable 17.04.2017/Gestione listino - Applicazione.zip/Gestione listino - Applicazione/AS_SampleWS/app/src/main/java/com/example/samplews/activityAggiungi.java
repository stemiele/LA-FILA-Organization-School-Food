package com.example.samplews;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class activityAggiungi extends Activity {
    EditText editNome;
    EditText editDescrizione;
    EditText editPrezzo;
    Button aggiungi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aggiungi);
        editNome = (EditText)findViewById(R.id.editTextNome);
        editDescrizione = (EditText)findViewById(R.id.editTextDescrizione);
        editPrezzo = (EditText)findViewById(R.id.editTextPrezzo);
        aggiungi = (Button) findViewById(R.id.buttonAggiungi);
        aggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // creo oggetto per comunicare con il web service che lavora in un thread di tipo AsyncTask
                CallWebService callWs = new CallWebService();
                callWs.execute(CallWebService.METHOD_NAME_ADD, editNome.getText().toString(), editDescrizione.getText().toString(),editPrezzo.getText().toString());
            }
        });
    }

}
