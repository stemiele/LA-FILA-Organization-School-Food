package com.example.samplews;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class activityElimina extends Activity {
    EditText editNome;
    Button elimina;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elimina);
        editNome = (EditText)findViewById(R.id.editTextNomeElimin);
        elimina = (Button) findViewById(R.id.buttonDelete);
        elimina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // creo oggetto per comunicare con il web service che lavora in un thread di tipo AsyncTask
                CallWebService callWs = new CallWebService();
                callWs.execute(CallWebService.METHOD_NAME_DELETE, editNome.getText().toString());
            }
        });
    }

}
