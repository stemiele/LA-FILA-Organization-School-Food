package com.example.samplews;

// http://kobjects.org/ksoap2/doc/api/org/ksoap2/package-summary.html
// http://simpligility.github.io/ksoap2-android/users.html
// http://amslaurea.unibo.it/3569/1/DeAngelis_Sebastiano_MetodologieEStrumentiDiAnticontraffazioneInAmbientiAndroid_.pdf
// http://143.225.81.37/www.mobilab.unina.it/tesi/Tesi_Guazzo.pdf

// http://www.thecrazyprogrammer.com/2016/11/android-soap-client-example-using-ksoap2.html
// https://www.codeproject.com/Tips/810432/Android-deserialize-KSoap-response-into-Complex-o
// http://binarylifebyanjula.blogspot.it/2013/11/android-webservices-ksoap2-complex.html
// http://stackoverflow.com/questions/8533390/how-to-retrieve-array-of-objects-as-a-result-from-ksoap-web-service-in-android?rq=1
// http://www.thejavaprogrammer.com/java-soap-web-services-tutorial/


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;


public class MainActivity extends Activity {

    private Button buttonAggiungi;
    private Button buttonModifica;
    private Button buttonElimina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        CallWebService callWS = new CallWebService();

        // richiamo il thread di tipo AsyncTask chiedendo l'esecuzione del web service
        // primo parametro: identificatore dell'operazione da richiamare
        // in questo caso si recuperano i valori da inserire nello spinner
        callWS.execute(CallWebService.METHOD_NAME_LIST);


        // aggiungo al bottone il gestione evento click
        buttonAggiungi = (Button) findViewById(R.id.buttonAggiungi);
        buttonAggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), activityAggiungi.class);
                startActivity(i);
            }
        });
        buttonElimina = (Button) findViewById(R.id.buttonElimina);
        buttonElimina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), activityElimina.class);
                startActivity(i);
            }
        });
        buttonModifica = (Button) findViewById(R.id.buttonModifica);
        buttonModifica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), activityModifica.class);
                startActivity(i);
            }
        });

    }
           // Toast.makeText(MainActivity.this, "NothingSelected", Toast.LENGTH_SHORT).show();

}
