package client;

import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	private final String SERVER_HOST = "172.16.102.60";
	  private final int SERVER_PORT = 3333;
	 
	  public static void main(String[] args) {
	      Client c = new Client();
	      try {
	          c.sendFile(new File("E:/test/prenotazione.txt"));
	      } catch (IOException e) {
	          e.printStackTrace();
	      }
	  }
	 
	  private void sendFile(File file) throws IOException {
	      Socket socket = null;
	      try {
	          socket = new Socket(SERVER_HOST, SERVER_PORT);
	      } catch (UnknownHostException e) {
	          e.printStackTrace();
	      } catch (IOException e) {
	          e.printStackTrace();
	      }
	 
	      ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
	      oos.reset();
	      oos.writeObject(file);
	      oos.flush();
	      oos.close();
	  }
	}