package server;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class ReceiverManager implements Runnable {
	 
	  private final String SAVE_DIR = "/E/miele/ServerSocket/uploads";
	 
	  private Socket socket;
	  private ObjectInputStream oin;
	  public ReceiverManager(Socket socket) {
	      this.socket = socket;
	  }
	 
	  public void run() {
	      try {
	          System.out.println("presa in carico nuova connessione da " + socket);
	 
	          // intercetto il file in arrivo
	          oin = new ObjectInputStream(socket.getInputStream());
	 
	          // imposto il nuovo file che dovro' salvare
	          // prendendone il nome originale
	          File saveFile = new File(SAVE_DIR + "/prenotazione.txt");
	 
	          // salvo il file
	          save(saveFile);
	 
	      } catch (Exception e) {
	          e.printStackTrace();
	      } finally {
	          try {
	              socket.close();
	          } catch (IOException e) { }
	      }
	  }
	  
	  private void save(File out) throws IOException {
		  String din = oin.readUTF();
		  String filename = din.toString();
	      System.out.println(" --ricezione prenotazione " + filename);
	 
	      // apro uno stream sul file che e' stato inviato
	      FileInputStream fis  = new FileInputStream(filename);
	      // scrivo uno stram per il salvataccio del nuovo file
	      FileOutputStream fos = new FileOutputStream(new File(SAVE_DIR + "/prenotazione.txt"));
	 
	      byte[] buf = new byte[1024];
	      int i = 0;
	      // riga per riga leggo il file originale per 
	      // scriverlo nello stram del file destinazione
	      while((i=fis.read(buf))!=-1) {
	          fos.write(buf, 0, i);
	      }
	      // chiudo gli streams
	      fis.close();
	      fos.close();
	 
	      System.out.println(" --ricezione prenotazione completata");
	  }
	}