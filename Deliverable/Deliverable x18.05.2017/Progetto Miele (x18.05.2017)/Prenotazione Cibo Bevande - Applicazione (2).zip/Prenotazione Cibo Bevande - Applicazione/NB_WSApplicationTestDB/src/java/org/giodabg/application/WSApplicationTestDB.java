/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.giodabg.application;
//Importo Librerie
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Gio
 */
@WebService(serviceName = "WSApplicationTestDB")
public class WSApplicationTestDB {

    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "aggiungiPrenotazioni")
    public boolean add(@WebParam(name = "nomePre") String nomePre, @WebParam(name = "quantita") int quantita) {
        boolean inserito = false;
 	String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost/tapschool";  //Nome Database TapSchool
        String USER = "root";
        String PASS = "";
        Connection conn = null;
        Statement stmt = null;
	 try {
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            String sql = "SELECT * from prenotazioni";
ResultSet rs = stmt.executeQuery(sql);

                // iterate through the java resultset
                while (rs.next()) {
                    //Retrieve by column name
                    String nomeprodotto = rs.getString("nomeprodotto");
		    if(nomeprodotto.equals(nomeProd)!=0){
			sql = "INSERT INTO prenotazioni(ID,nomeprodotto,quantita) VALUES(NULL,nomePre,quantita)";  //Query per aggiunta prenotazione
			ResultSet rs = stmt.executeQuery(sql);
			inserito = true;
		    }
                }

                rs.close();
            }
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
        return inserito;
    }

//operazione Modifica Prenotazione , permette di modificare il nome
@WebMethod(operationName = "modificaPrenotazioni")
    public boolean modifica(@WebParam(name = "nomePre") String nomePre, @WebParam(name = "nuovoNome") String nuovoNome, @WebParam(name = "quantita") int quantita) {
        boolean modificato = false;
 	String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost/tapschool";
        String USER = "root";
        String PASS = "";
        Connection conn = null;
        Statement stmt = null;
	 try {
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            String sql = "SELECT * FROM prenotazioni WHERE nomeprodotto = " + nomePre;    	//Query per modifica prenotazione
ResultSet rs = stmt.executeQuery(sql);

                // iterate through the java resultset
                while (rs.next()) {
                    //Retrieve by column name
                    String nomeprodotto = rs.getString("nomeprodotto");
			/*sql = "query";
			ResultSet rs = stmt.executeQuery(sql);
			modificato = true;*/
                }

                rs.close();
            }
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
        return modificato;
    }

//Operazione Elimina , permette di eliminare in base al nome.
@WebMethod(operationName = "eliminaPrenotazioni")
    public boolean delete(@WebParam(name = "nomePre") String nomePre{
        boolean eliminato = false;
 	String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost/tapschool";
        String USER = "root";
        String PASS = "";
        Connection conn = null;
        Statement stmt = null;
	 try {
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            String sql = "DELETE FROM prenotazioni WHERE nomeprodotto = " + nomePre;			//Query per modifica prenotazione.
ResultSet rs = stmt.executeQuery(sql);
eliminato = true;

                rs.close();
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
        return eliminato;
    }
}
