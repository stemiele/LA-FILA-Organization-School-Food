package com.example.samplews;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;


public class MainActivity extends Activity {

    private Button buttonAggiungi;
    private Button buttonModifica;
    private Button buttonElimina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        CallWebService callWS = new CallWebService();

        // richiamo il thread di tipo AsyncTask chiedendo l'esecuzione del web service
        // primo parametro: identificatore dell'operazione da richiamare
        // in questo caso si recuperano i valori da inserire nello spinner
        callWS.execute(CallWebService.METHOD_NAME_LIST);


        // aggiungo al bottone il gestione evento click
        buttonAggiungi = (Button) findViewById(R.id.buttonAggiungi);
        buttonAggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), activityAggiungi.class);
                startActivity(i);
            }
        });
        buttonElimina = (Button) findViewById(R.id.buttonElimina);
        buttonElimina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), activityElimina.class);
                startActivity(i);
            }
        });
        buttonModifica = (Button) findViewById(R.id.buttonModifica);
        buttonModifica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), activityModifica.class);
                startActivity(i);
            }
        });

    }
           // Toast.makeText(MainActivity.this, "NothingSelected", Toast.LENGTH_SHORT).show();

}
