package com.example.samplews;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class activityAggiungi extends Activity {
    EditText editNome; //Nome Prenotazione
    EditText editQuantita; //Quantità
    Button aggiungi; //Bottone per aggiungere
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aggiungi);
        editNome = (EditText)findViewById(R.id.editTextNome);
        editQuantita = (EditText)findViewById(R.id.editTextQuantita);
        aggiungi = (Button) findViewById(R.id.buttonAggiungi);
        aggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
         
		 
                CallWebService callWs = new CallWebService();
                callWs.execute(CallWebService.METHOD_NAME_ADD, editNome.getText().toString(),editQuantita.getText().toString());
				Context context = getApplicationContext();
                CharSequence text = "Elemento inserito";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context,text,duration);
                toast.show();
            }
        });
    }

}
