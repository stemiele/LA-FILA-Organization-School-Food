<html>
	<head>
		<title>DB Cinema</title>
	</head>
	<body>
		<h1> <p align="center">Benvenuti</h1> </p>
		<h1> BRAVO
	</body>
</html>