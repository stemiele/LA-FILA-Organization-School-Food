<?php
	session_start();
	$nomeUtente = $_POST["Username"];
	$password1 = md5($_POST["Psw1"]);
	$password2 = md5($_POST["Psw2"]);
	$esiste = false;
	if(strcmp($password1,$password2)!=0)
		echo "Le due password devono essere uguale <br>";
	else{
		$conn = new mysqli("localhost","root","","cinema_mastro");
		$sqlControllo = "SELECT * from utente WHERE username = '$nomeUtente'";
		$result = $conn->query($sqlControllo);
		if($result->num_rows > 0)
		{
			while(($row = $result->fetch_assoc())){
				if(strcmp($row["username"],$nomeUtente)==0){
					$esiste = true;
					break;
				}
			}
			if($esiste==false){
				$sql = "INSERT INTO utente (username, password) VALUES ('$nomeUtente', '$password1')";
				$conn->query($sql);
				include("index1.php");
			}
			else
				echo "L'utente è già esistente <br>";
		}
		else{
			$sql = "INSERT INTO utente (username, password) VALUES ('$nomeUtente', '$password1')";
			$conn->query($sql);
			include("index1.php");
		}
	}
?>