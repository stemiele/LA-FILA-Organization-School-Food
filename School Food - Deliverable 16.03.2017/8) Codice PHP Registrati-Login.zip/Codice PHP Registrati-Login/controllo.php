<?php
	session_start();
	$controlloNome=isset($_POST['selectNome']);
	$controlloCitta=isset($_POST['selectCitta']);
	$controlloNazione=isset($_POST['selectNazione']);
	$controlloAnno=isset($_POST['selectAnno']);
	
	$conn = new mysqli("localhost","root","","cinema_mastro");
			$sql = "SELECT * FROM attori JOIN recita ON attori.CodAttore = recita.CodAttore 
										 JOIN proiezioni ON proiezioni.CodFilm = recita.CodFilm 
										 JOIN sale ON sale.CodSala = proiezioni.CodSala 
										 JOIN film ON film.CodFilm = proiezioni.CodFilm 
										 WHERE 1 AND";
										 			 
			$sql .= " Nome LIKE '%$controlloNome%'";
			$sql .= " AND Nazionalita LIKE '$controlloNazione'";
			$sql .= " AND AnnoProduzione LIKE '%$controlloAnno%'";
			$sql .= " AND Citta LIKE '%$controlloCitta%'";
			//echo "query:". $sql."</br>";
			$result = $conn->query($sql);
			if($result->num_rows > 0)
			{
				while(($row = $result->fetch_assoc()))
				{
					echo "titolo film: " .$row["Titolo"]."<br>";
				}
			}
?>