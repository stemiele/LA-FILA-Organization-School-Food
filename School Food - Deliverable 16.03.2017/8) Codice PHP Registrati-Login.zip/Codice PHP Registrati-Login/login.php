<?php
	session_start();
	$utenteForm = $_POST["Username"];
	$passwordForm = md5($_POST["Psw"]);
	   
    $conn = new mysqli("localhost","root","","cinema_mastro");
	$sql = "SELECT * FROM utente WHERE username = '$utenteForm' AND password = '$passwordForm'";
	$result = $conn->query($sql);
	if($result->num_rows == 0){
		include("pswerrata.html");
	}
	else
		include("index1.php");
?>